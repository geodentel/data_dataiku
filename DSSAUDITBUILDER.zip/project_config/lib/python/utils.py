import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

def write_to_folder(df, name, folder_id):

    try:
        client = dataiku.api_client()
        instanceName = client.get_general_settings().get_raw()['nodeName']
    except:
        instanceName = 'dss'

    df['instanceName'] = instanceName

    folder = dataiku.Folder(folder_id) # get folder
    with folder.get_writer(name+'_'+instanceName+'.csv') as w:
        w.write(df.to_csv(index=False).encode("utf-8"))
