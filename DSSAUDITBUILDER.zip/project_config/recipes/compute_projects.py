import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()
projects=[]

for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    summary = project.get_summary()
    projects.append(summary)

projects_df = pd.DataFrame(projects)

write_to_folder(projects_df, "project", "d9wMkfDd")