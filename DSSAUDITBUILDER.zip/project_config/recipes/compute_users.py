import dataiku
import pandas as pd, numpy as np
from utils import write_to_folder

client = dataiku.api_client()
users=client.list_users()

users_df = pd.DataFrame(
    users,
    columns = ['login', 'sourceType', 'displayName', 'groups', 'email', 'userProfile', 'enabled']
)

write_to_folder(users_df, "users", "UKrg8LEY")