import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()

code_env_usages_df = pd.DataFrame(client.list_code_env_usages())

write_to_folder(code_env_usages_df, "code_env_usages", "38rN676F")