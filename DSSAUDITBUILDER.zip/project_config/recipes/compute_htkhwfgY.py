import dataiku
from utils import write_to_folder

name = "dss_flow_actions"
folder_id = "htkhwfgY"

df = dataiku.Dataset(name).get_dataframe()
write_to_folder(df, name, folder_id)

