import dataiku
from utils import write_to_folder

name = "dss_cluster_tasks"
folder_id = "l5u0mNzZ"

df = dataiku.Dataset(name).get_dataframe()
write_to_folder(df, name, folder_id)
