import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder


client = dataiku.api_client()

ml_tasks=[]
for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    for t in project.list_ml_tasks()['mlTasks']:
        t['project_key'] = project_key
        ml_tasks.append(t)
            
ml_tasks_df = pd.DataFrame.from_dict(ml_tasks)
write_to_folder(ml_tasks_df, "ml_tasks", "doDUsSMo")