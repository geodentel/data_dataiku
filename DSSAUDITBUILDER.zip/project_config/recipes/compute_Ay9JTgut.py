import dataiku
from utils import write_to_folder

name = "dss_commits"
folder_id = "Ay9JTgut"

df = dataiku.Dataset(name).get_dataframe()
write_to_folder(df, name, folder_id)
