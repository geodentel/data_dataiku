import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()

wiki =[]
for project_key in [x for x in client.list_project_keys() if x not in ["PRODUCTRECO"]]:
    project = client.get_project(project_key)
    w = {
        'project_key': project_key,
        'list_wiki': project.get_wiki().list_articles()
    }
    wiki.append(w)
            
wiki_df = pd.DataFrame.from_dict(wiki)
write_to_folder(wiki_df, "wiki", "UGfv9eFp")