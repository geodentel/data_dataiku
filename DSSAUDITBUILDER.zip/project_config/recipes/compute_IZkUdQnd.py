import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
from utils import write_to_folder

client = dataiku.api_client()
write_to_folder(pd.DataFrame(client.list_plugins()), "plugin", "IZkUdQnd")