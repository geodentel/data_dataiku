# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder


client = dataiku.api_client()

recipes=[]
for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    for r in project.list_recipes():
         recipes.append({
             'project_key': project_key, 
             'recipe_type' : r['type'],
             'recipe_last_modif_user' : r['creationTag']['lastModifiedBy'] if "creationTag" in r else "",
             'recipe_last_modif_date' : r['creationTag']['lastModifiedOn'] if "creationTag" in r else "",
             'recipe_creation_user' : r['versionTag']['lastModifiedBy'] if "creationTag" in r else "",
             'recipe_creation_date' : r['versionTag']['lastModifiedOn'] if "creationTag" in r else "",
             'recipe_tags': r['tags']
         })
            
recipes_df = pd.DataFrame.from_dict(recipes)

write_to_folder(recipes_df, "recipe", "ia0OeRqW")