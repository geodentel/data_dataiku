import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder


client = dataiku.api_client()

api_services=[]
for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    for p in project.list_api_services():
        p['project_key'] = project_key
        api_services.append(p)
            
api_services_df = pd.DataFrame.from_dict(api_services)
write_to_folder(api_services_df, "api_services", "tsvfSz9g")