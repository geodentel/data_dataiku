import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()

webapps =[]
for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    for p in project.list_webapps():
        p['project_key'] = project_key
        webapps.append(p)
            
webapps_df = pd.DataFrame.from_dict(webapps)
write_to_folder(webapps_df, "webapps", "2cmFf1K9")