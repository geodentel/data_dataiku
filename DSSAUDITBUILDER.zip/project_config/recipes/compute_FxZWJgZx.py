# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
workspaces = []
for workspace in client.list_workspaces(True):
    w = {
        'workspace_key': workspace.workspace_key,
        'workspace_name': workspace.get_settings().display_name,
        'workspace_description': workspace.get_settings().description
    }
    if len(workspace.list_objects()) > 0:
        for obj in workspace.list_objects():
            w_obj = w.copy()
            w_obj['obj_id'] = obj.data["id"]
            w_obj['obj_name'] = obj.data["displayName"]
            
            if 'reference' in obj.data:
                w_obj['obj_type'] = obj.data['reference']['type']
      
            if 'htmlLink' in obj.data:
                w_obj['obj_type'] = 'HTMLLINK'
                
            if 'appId' in obj.data:              
                w_obj['obj_type'] = 'APP'
            workspaces.append(w_obj)
    else:
            workspaces.append(w)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
workspaces_df = pd.DataFrame.from_dict(workspaces)
write_to_folder(workspaces_df, "workspaces", "FxZWJgZx")