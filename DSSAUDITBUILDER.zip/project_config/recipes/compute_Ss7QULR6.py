import json
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

from utils import write_to_folder

client = dataiku.api_client()

project = client.get_project(dataiku.default_project_key())
flow = project.get_flow()
flowzones = [f.name for f in flow.list_zones()]

flowzones =[]
for project_key in client.list_project_keys():
    project = client.get_project(project_key)
    flow = project.get_flow()
    flowzones += [{
        'project_key': project_key, 
        'flowzone_id': p.id, 
        'flowzone_name': p.name} for p in flow.list_zones()
    ]

flowzones_df = pd.DataFrame.from_dict(flowzones)

write_to_folder(flowzones_df, "flowzones", "Ss7QULR6")